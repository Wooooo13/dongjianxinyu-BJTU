// 立即执行函数，防止变量污染 (function() {})();

// 柱状图模块2
(function () {
 $.get('/analysis4', function (data0) {
    data = $.parseJSON(data0)
  // 1.实例化对象
  var myChart = echarts.init(document.querySelector(".bar2 .chart"));
  // 2.指定配置项和数据
  var option = {
    color: ['#3FBFBD'],
    // 提示框组件
    tooltip: {
      trigger: 'axis',
      axisPointer: { // 坐标轴指示器，坐标轴触发有效
        type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    // 修改图表位置大小
    grid: {
      left: '0%',
      top: '10px',
      right: '0%',
      bottom: '4%',
      containLabel: true
    },
    // x轴相关配置
    xAxis: [{
      type: 'category',
      data: data.xdata,
      axisTick: {
        alignWithLabel: true
      },
      // 修改刻度标签，相关样式
      axisLabel: {
        color: "rgba(255,255,255,0.8)",
        fontSize: 10
      },
      // x轴样式不显示
      axisLine: {
        show: false
      }
    }],
    // y轴相关配置
    yAxis: [{
      type: 'value',
      // 修改刻度标签，相关样式
      axisLabel: {
        color: "rgba(255,255,255,0.6)",
        fontSize: 12
      },
      // y轴样式修改
      axisLine: {
        lineStyle: {
          color: "rgba(255,255,255,0.6)",
          width: 2
        }
      },
      // y轴分割线的颜色
      splitLine: {
        lineStyle: {
          color: "rgba(255,255,255,0.1)"
        }
      }
    }],
    // 系列列表配置
    series: [{
      name: '浏览量',
      type: 'bar',
      barWidth: '35%',
      // ajax传动态数据
      data: data.ydata,
      itemStyle: {
        // 修改柱子圆角
        barBorderRadius: 5
      }
    }]
  };
  // 3.把配置项给实例对象
  myChart.setOption(option);

  // 4.让图表随屏幕自适应
  window.addEventListener('resize', function () {
    myChart.resize();
  })
    });
})();

 // 折线图模块1
 (function () {
 $.get('/analysis3', function (data0) {
   data = $.parseJSON(data0)


   var myChart = echarts.init(document.querySelector(".line .chart"));

   var option = {
     // 修改两条线的颜色
     color: ['#00f2f1', '#ed3f35'],
     tooltip: {
       trigger: 'axis'
     },
     // 图例组件
     legend: {
       // 当serise 有name值时， legend 不需要写data
       // 修改图例组件文字颜色
       textStyle: {
         color: '#4c9bfd'
       },
       right: '10%',
     },
     grid: {
       top: "20%",
       left: '3%',
       right: '4%',
       bottom: '3%',
       containLabel: true,
       show: true, // 显示边框
       borderColor: '#012f4a' // 边框颜色
     },
     xAxis: {
       type: 'category',
       boundaryGap: false, // 去除轴间距
       data: data.xdata,
       // 去除刻度线
       axisTick: {
         show: false
       },
       axisLabel: {
         color: "#4c9bfb" // x轴文本颜色
       },
       axisLine: {
         show: false // 去除轴线
       }
     },
     yAxis: {
       type: 'value',
       // 去除刻度线
       axisTick: {
         show: false
       },
       axisLabel: {
         color: "#4c9bfb" // x轴文本颜色
       },
       axisLine: {
         show: false // 去除轴线
       },
       splitLine: {
         lineStyle: {
           color: "#012f4a"
         }
       }
     },
     series: [{
         type: 'line',
         smooth: true, // 圆滑的线
         name: '点赞数',
         data: data.ydata
       }
     ]
   };

   myChart.setOption(option);

   // 4.让图表随屏幕自适应
   window.addEventListener('resize', function () {
     myChart.resize();
   })


   });
 })();



// 饼形图1
(function () {
$.get('/analysis1', function (data0) {
  data = $.parseJSON(data0)

    list = []
       for(j = 0,len=data.xdata.length; j < len; j++) {
            dic = {}
            dic['name'] = data.xdata[j]
            dic['value'] = data.ydata[j]
            list.push(dic)
       }
  var myChart = echarts.init(document.querySelector(".pie .chart"));
  var option = {
    color: ["#1089E7", "#F57474", "#56D0E3", "#F8B448", "#8B78F6"],
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c}'
    },
    legend: {
      // 垂直居中,默认水平居中
      // orient: 'vertical',

      bottom: 0,
      left: 10,
      // 小图标的宽度和高度
      itemWidth: 10,
      itemHeight: 10,
      // 修改图例组件的文字为 12px
      textStyle: {
        color: "rgba(255,255,255,.5)",
        fontSize: "10"
      }
    },
    series: [{
      name: '人数',
      type: 'pie',
      // 设置饼形图在容器中的位置
      center: ["50%", "42%"],
      // 修改饼形图大小，第一个为内圆半径，第二个为外圆半径
      radius: ['40%', '60%'],
      avoidLabelOverlap: false,
      // 图形上的文字
      label: {
        show: false,
        position: 'center'
      },
      // 链接文字和图形的线
      labelLine: {
        show: false
      },
      data: list
    }]
  };

  myChart.setOption(option);
  window.addEventListener('resize', function () {
    myChart.resize();
  })
  });
})();

// 饼形图2
(function () {
$.get('/analysis2', function (data0) {
  data = $.parseJSON(data0)

    list = []
       for(j = 0,len=data.xdata.length; j < len; j++) {
            dic = {}
            dic['name'] = data.xdata[j]
            dic['value'] = data.ydata[j]
            list.push(dic)
       }

  var myChart = echarts.init(document.querySelector('.pie2 .chart'));
  var option = {
    color: ['#60cda0', '#ed8884', '#ff9f7f', '#0096ff', '#9fe6b8', '#32c5e9', '#1d9dff'],
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    legend: {
      bottom: 0,
      itemWidth: 10,
      itemHeight: 10,
      textStyle: {
        color: "rgba(255,255,255,.5)",
        fontSize: 10
      }
    },
    series: [{
      name: '评论数',
      type: 'pie',
      radius: ["10%", "60%"],
      center: ['50%', '40%'],
      // 半径模式  area面积模式
      roseType: 'radius',
      // 图形的文字标签
      label: {
        fontsize: 10
      },
      // 引导线调整
      labelLine: {
        // 连接扇形图线长(斜线)
        length: 6,
        // 连接文字线长(横线)
        length2: 8
      },
      data: list
    }]
  };

  myChart.setOption(option);
  window.addEventListener('resize', function () {
    myChart.resize();
  })
});
})();

(function () {
$.get('/analysis5', function (data0) {
  data = $.parseJSON(data0)
   list = []
       for(j = 0,len=data.xdata.length; j < len; j++) {
            dic = {}
            dic['name'] = data.xdata[j]
            dic['value'] = data.ydata[j]
            list.push(dic)
       }
var myChart = echarts.init(document.querySelector(".map .chart"));
   	// 指定图表的配置项和数据
		var option = {
			 backgroundColor:'#fff',
                    tooltip: {
                        show: false
                    },
                    series: [{
                        type: 'wordCloud',
                        gridSize: 1,
                        sizeRange: [12, 100],
                        rotationRange: [-45, 0, 45, 90],
                       // maskImage: maskImage,
                       textStyle: {
            fontFamily: 'sans-serif',
            fontWeight: 'bold',
            // Color can be a callback function or a color string
            color: function () {
                // Random color
                return 'rgb(' + [
                    Math.round(Math.random() * 255),
                    Math.round(Math.random() * 255),
                    Math.round(Math.random() * 255)
                ].join(',') + ')';
            }
        },
                        left: 'center',
                        top: 'center',
                        // width: '96%',
                        // height: '100%',
                        right: null,
                        bottom: null,
                        // width: 300,
                        // height: 200,
                        // top: 20,
                        data: list
                    }]
		};

		// 使用刚指定的配置项和数据显示图表。
		myChart.setOption(option);
  window.addEventListener('resize', function () {
    myChart.resize();
  })
  });
})();
